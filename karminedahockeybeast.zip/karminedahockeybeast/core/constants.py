EMBED_FOOTER_TEXT = "github.com/h0nde/roblox-claimable-group-finder"

DEFAULT_ID_SLACK = 100000
DEFAULT_RANGES = (
    (1, 1400000),
    (2520000, 7960000),
    (8000000, 9930000),
    (9960000, 10760000),
    (10790000, 12340000)
)