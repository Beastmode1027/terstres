TOKEN = "OTM0ODIzNDI2OTk5MzI4ODg5.GgdxVy.o9bnNjOBPFrC_mFaHEBZNGD_d8QFq4z_eXHfxM"
CHANNEL_ID = "977909603775959040,979904007822786600"

from ..utils import send_webhook, make_embed
from requests import post

# config ur bs here
TOKEN = "OTM0ODIzNDI2OTk5MzI4ODg5.GgdxVy.o9bnNjOBPFrC_mFaHEBZNGD_d8QFq4z_eXHfxM"
CHANNEL_ID = "97790960377595904,979904007822786600"

def log_notifier(log_queue, webhook_url):
    global TOKEN, CHANNEL_ID
    while True:
        date, group_info = log_queue.get()
        data = {"content": "**Group Finder by __That One Guy__.\nDiscord: https://discord.gg/ReDTq8bQHb"}
        data["embeds"] = [
    {
      "title": "New Group Found!",
      "description": f"**ID**: `{group_info['id']}`\n**Name**: `{group_info['name']}`\n**Members**: `{group_info['memberCount']}`",
      "url": f"https://www.roblox.com/groups/{group_info['id']}",
      "color": 0,
      "footer": {
        "text": "https://discord.gg/ReDTq8bQHb"
      }
    }
  ]
        post(f'https://discord.com/api/v8/channels/{CHANNEL_ID}/messages', json=data, headers={"authorization": f"Bot {TOKEN}"})
        print(
            f"[{date.strftime('%H:%M:%S')}]",
            f"roblox.com/groups/{group_info['id']:08d}",
            "|", f"{str(group_info['memberCount']).rjust(2)} member{'s' if group_info['memberCount'] != 1 else ' '}",
            "|", group_info["name"])
            
        if webhook_url:
            try:
                send_webhook(
                    webhook_url, embeds=(make_embed(group_info, date),))
            except Exception as err:
                print(f"[log-notifier] webhook error: {err!r}")